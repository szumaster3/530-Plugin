package cacheops.cache

interface Definition {
    var id: Int
}