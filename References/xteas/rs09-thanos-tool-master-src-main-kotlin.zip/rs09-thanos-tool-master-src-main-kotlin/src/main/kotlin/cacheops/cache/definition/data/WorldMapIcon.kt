package cacheops.cache.definition.data

data class WorldMapIcon(
    var id: Int = -1,
    var position: Int = -1
)